"""Custom MCP server: ChatGPT → official X API v2 (create posts / threads)."""

__version__ = "1.0.0"
