"""MCP server (Streamable HTTP + optional SSE) exposing X posting tools for ChatGPT."""

from __future__ import annotations

import json
from typing import Annotated, Any

from mcp.server.mcpserver import MCPServer
from mcp.types import ToolAnnotations
from pydantic import Field

from .config import Settings, load_settings
from .x_client import XAPIError, XClient, dry_run_payload, summarize_post_response

INSTRUCTIONS = (
    "This server posts to X (Twitter) using the owner's official X API credentials. "
    "Before create_post or create_thread, confirm the exact text with the user unless "
    "they already approved it. Prefer dry_run=true first when unsure. "
    "Call get_me once to verify which account will publish. "
    "Do not invent credentials; do not scrape X; do not use Metricool."
)

mcp = MCPServer(
    name="x-chatgpt-mcp",
    title="X Poster for ChatGPT",
    description="Post and thread on X via the official X API v2",
    instructions=INSTRUCTIONS,
    version="1.0.0",
)

_settings: Settings | None = None


def get_settings() -> Settings:
    global _settings
    if _settings is None:
        _settings = load_settings()
    return _settings


def _client() -> XClient:
    return XClient(get_settings())


def _ok(payload: dict[str, Any]) -> str:
    return json.dumps(payload, indent=2, ensure_ascii=False)


def _err(exc: BaseException) -> str:
    if isinstance(exc, XAPIError):
        return _ok(
            {
                "ok": False,
                "error": str(exc),
                "http_status": exc.status,
                "x_response": exc.body,
            }
        )
    return _ok({"ok": False, "error": str(exc)})


@mcp.tool(
    name="get_me",
    title="Get authenticated X account",
    description=(
        "Use this when you need to verify which X account the MCP server will post as, "
        "or to confirm credentials work. Calls GET /2/users/me. Read-only."
    ),
    annotations=ToolAnnotations(
        readOnlyHint=True,
        destructiveHint=False,
        openWorldHint=True,
        idempotentHint=True,
    ),
)
async def get_me() -> str:
    try:
        data = await _client().get_me()
        user = data.get("data") or {}
        return _ok(
            {
                "ok": True,
                "id": user.get("id"),
                "name": user.get("name"),
                "username": user.get("username"),
                "url": (
                    f"https://x.com/{user['username']}"
                    if user.get("username")
                    else None
                ),
                "raw": data,
            }
        )
    except Exception as exc:  # noqa: BLE001 — surface cleanly to ChatGPT
        return _err(exc)


@mcp.tool(
    name="create_post",
    title="Create an X post",
    description=(
        "Use this when the user wants to publish a single post (tweet) on X. "
        "Optional reply_to makes it a reply to an existing post id. "
        "Set dry_run=true to preview the payload without calling the X API. "
        "Confirm the final text with the user before dry_run=false. "
        "Calls POST /2/tweets."
    ),
    annotations=ToolAnnotations(
        readOnlyHint=False,
        destructiveHint=False,
        openWorldHint=True,
        idempotentHint=False,
    ),
)
async def create_post(
    text: Annotated[
        str,
        Field(description="Post body. Most accounts: max 280 characters."),
    ],
    reply_to: Annotated[
        str | None,
        Field(description="Optional existing post id to reply to (in_reply_to_tweet_id)."),
    ] = None,
    dry_run: Annotated[
        bool,
        Field(description="If true, preview the request without calling X. Default false."),
    ] = False,
) -> str:
    text = (text or "").strip()
    if not text:
        return _ok({"ok": False, "error": "text is required and cannot be empty"})
    if dry_run:
        return dry_run_payload(
            "POST /2/tweets",
            text=text,
            reply_to=reply_to,
        )
    try:
        resp = await _client().create_post(text, reply_to=reply_to)
        summary = summarize_post_response(resp)
        return _ok({"ok": True, **summary})
    except Exception as exc:  # noqa: BLE001
        return _err(exc)


@mcp.tool(
    name="create_thread",
    title="Create an X thread",
    description=(
        "Use this when the user wants a multi-post thread on X. "
        "Pass texts as an ordered list; each post after the first replies to the previous. "
        "Set dry_run=true to preview without posting. Confirm copy before dry_run=false. "
        "Calls POST /2/tweets once per item."
    ),
    annotations=ToolAnnotations(
        readOnlyHint=False,
        destructiveHint=False,
        openWorldHint=True,
        idempotentHint=False,
    ),
)
async def create_thread(
    texts: Annotated[
        list[str],
        Field(description="Ordered list of post bodies (at least one non-empty string)."),
    ],
    dry_run: Annotated[
        bool,
        Field(description="If true, preview without posting. Default false."),
    ] = False,
) -> str:
    cleaned = [(t or "").strip() for t in (texts or [])]
    if not cleaned or any(not t for t in cleaned):
        return _ok(
            {
                "ok": False,
                "error": "texts must be a non-empty list of non-empty strings",
            }
        )
    if dry_run:
        return dry_run_payload(
            "POST /2/tweets (thread)",
            posts=[{"index": i, "text": t} for i, t in enumerate(cleaned)],
            note="Each post after index 0 will set reply.in_reply_to_tweet_id to the previous id",
        )
    try:
        results = await _client().create_thread(cleaned)
        posts = [summarize_post_response(r) for r in results]
        return _ok(
            {
                "ok": True,
                "count": len(posts),
                "root_id": posts[0].get("id") if posts else None,
                "root_url": posts[0].get("url") if posts else None,
                "posts": posts,
            }
        )
    except Exception as exc:  # noqa: BLE001
        return _err(exc)


def build_transport_security(settings: Settings | None = None):
    """Allow public tunnel hostnames for ChatGPT → MCP."""
    from mcp.server.transport_security import TransportSecuritySettings

    s = settings or get_settings()
    if s.disable_dns_rebinding:
        return TransportSecuritySettings(enable_dns_rebinding_protection=False)

    hosts = list(s.allowed_hosts) or []
    # Always permit localhost variants for local Inspector
    for h in ("127.0.0.1:*", "localhost:*", "[::1]:*"):
        if h not in hosts:
            hosts.append(h)

    origins = list(s.allowed_origins) or []
    for o in ("http://127.0.0.1:*", "http://localhost:*", "https://chatgpt.com"):
        if o not in origins:
            origins.append(o)

    return TransportSecuritySettings(
        enable_dns_rebinding_protection=True,
        allowed_hosts=hosts,
        allowed_origins=origins,
    )


def create_http_app(settings: Settings | None = None):
    """ASGI app for uvicorn: Streamable HTTP at /mcp."""
    s = settings or get_settings()
    # Touch tools so they are registered (decorators already ran at import)
    return mcp.streamable_http_app(
        streamable_http_path="/mcp",
        json_response=True,
        stateless_http=True,
        host=s.host,
        transport_security=build_transport_security(s),
    )


# Default ASGI app for: uvicorn x_chatgpt_mcp.server:app
app = create_http_app()
