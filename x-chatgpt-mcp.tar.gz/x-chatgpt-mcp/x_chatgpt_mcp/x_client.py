"""Thin official X API v2 client (posts + users/me only).

Endpoints used (evidence for README):
  GET  {base}/2/users/me
  POST {base}/2/tweets
"""

from __future__ import annotations

import json
from typing import Any

import httpx
from authlib.integrations.httpx_client import AsyncOAuth1Client

from .config import Settings


class XAPIError(Exception):
    def __init__(self, status: int, body: Any, message: str | None = None):
        self.status = status
        self.body = body
        super().__init__(message or f"X API HTTP {status}: {body}")


class XClient:
    def __init__(self, settings: Settings):
        self.settings = settings
        settings.require_auth_ready()
        self._mode = settings.auth_mode
        assert self._mode in {"oauth1", "oauth2"}

    def _url(self, path: str) -> str:
        return f"{self.settings.api_base_url}{path}"

    async def _request(
        self,
        method: str,
        path: str,
        *,
        json_body: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        if self._mode == "oauth2":
            headers = {
                "Authorization": f"Bearer {self.settings.access_token}",
                "Content-Type": "application/json",
            }
            async with httpx.AsyncClient(timeout=30.0) as client:
                resp = await client.request(
                    method,
                    self._url(path),
                    headers=headers,
                    json=json_body,
                    params=params,
                )
        else:
            async with AsyncOAuth1Client(
                client_id=self.settings.api_key,
                client_secret=self.settings.api_secret,
                token=self.settings.access_token,
                token_secret=self.settings.access_token_secret,
                timeout=30.0,
            ) as client:
                resp = await client.request(
                    method,
                    self._url(path),
                    json=json_body,
                    params=params,
                    headers={"Content-Type": "application/json"} if json_body else None,
                )

        try:
            data = resp.json()
        except Exception:
            data = {"raw": resp.text}

        if resp.status_code >= 400:
            raise XAPIError(resp.status_code, data)
        if not isinstance(data, dict):
            return {"data": data}
        return data

    async def get_me(self) -> dict[str, Any]:
        """GET /2/users/me — verify user-context auth."""
        return await self._request(
            "GET",
            "/2/users/me",
            params={"user.fields": "id,name,username,description,public_metrics"},
        )

    async def create_post(
        self,
        text: str,
        *,
        reply_to: str | None = None,
    ) -> dict[str, Any]:
        """POST /2/tweets — create a post (optionally as a reply)."""
        body: dict[str, Any] = {"text": text}
        if reply_to:
            body["reply"] = {"in_reply_to_tweet_id": str(reply_to)}
        return await self._request("POST", "/2/tweets", json_body=body)

    async def create_thread(self, texts: list[str]) -> list[dict[str, Any]]:
        """Post a thread: first post, then each next as a reply to the previous."""
        if not texts:
            raise ValueError("texts must be a non-empty list")
        results: list[dict[str, Any]] = []
        previous_id: str | None = None
        for i, text in enumerate(texts):
            if not (text or "").strip():
                raise ValueError(f"texts[{i}] is empty")
            resp = await self.create_post(text.strip(), reply_to=previous_id)
            results.append(resp)
            data = resp.get("data") or {}
            previous_id = str(data.get("id") or "")
            if not previous_id:
                raise XAPIError(
                    500,
                    resp,
                    message=f"Thread stopped at index {i}: response missing data.id",
                )
        return results


def summarize_post_response(resp: dict[str, Any]) -> dict[str, Any]:
    data = resp.get("data") or {}
    post_id = data.get("id")
    return {
        "id": post_id,
        "text": data.get("text"),
        "url": f"https://x.com/i/web/status/{post_id}" if post_id else None,
        "raw": resp,
    }


def dry_run_payload(kind: str, **fields: Any) -> str:
    return json.dumps(
        {"dry_run": True, "would_call": kind, **fields},
        indent=2,
        ensure_ascii=False,
    )
