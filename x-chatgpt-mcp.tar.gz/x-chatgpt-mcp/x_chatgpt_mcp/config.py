"""Load settings from environment / .env. Never hardcode secrets."""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

from dotenv import load_dotenv

# Load .env from project root (parent of package) if present
_ROOT = Path(__file__).resolve().parent.parent
load_dotenv(_ROOT / ".env")
load_dotenv()  # also cwd


def _bool(name: str, default: bool = False) -> bool:
    raw = os.getenv(name)
    if raw is None or raw.strip() == "":
        return default
    return raw.strip().lower() in {"1", "true", "yes", "on"}


def _csv(name: str) -> list[str]:
    raw = os.getenv(name, "") or ""
    return [p.strip() for p in raw.split(",") if p.strip()]


@dataclass(frozen=True)
class Settings:
    # X auth
    access_token: str | None
    api_key: str | None
    api_secret: str | None
    access_token_secret: str | None
    api_base_url: str

    # HTTP
    host: str
    port: int
    allowed_hosts: list[str]
    allowed_origins: list[str]
    disable_dns_rebinding: bool

    @property
    def auth_mode(self) -> str | None:
        """Return 'oauth1', 'oauth2', or None if incomplete."""
        if (
            self.api_key
            and self.api_secret
            and self.access_token
            and self.access_token_secret
        ):
            return "oauth1"
        if self.access_token and not self.access_token_secret:
            return "oauth2"
        # Partial OAuth1 (access token set with secret missing) — treat as incomplete oauth1
        if self.access_token_secret or self.api_key or self.api_secret:
            return None
        return None

    def require_auth_ready(self) -> None:
        mode = self.auth_mode
        if mode == "oauth1" or mode == "oauth2":
            return
        missing = []
        if not self.access_token:
            missing.append("X_ACCESS_TOKEN")
        # Heuristic message
        raise RuntimeError(
            "X API credentials are not configured. "
            "Set either OAuth 2.0 user token (X_ACCESS_TOKEN) or all four OAuth 1.0a "
            "vars (X_API_KEY, X_API_SECRET, X_ACCESS_TOKEN, X_ACCESS_TOKEN_SECRET). "
            f"See .env.example. Missing/incomplete; hint vars: {', '.join(missing) or 'check OAuth 1.0a quartet'}."
        )


def load_settings() -> Settings:
    return Settings(
        access_token=(os.getenv("X_ACCESS_TOKEN") or "").strip() or None,
        api_key=(os.getenv("X_API_KEY") or "").strip() or None,
        api_secret=(os.getenv("X_API_SECRET") or "").strip() or None,
        access_token_secret=(os.getenv("X_ACCESS_TOKEN_SECRET") or "").strip() or None,
        api_base_url=(os.getenv("X_API_BASE_URL") or "https://api.x.com").rstrip("/"),
        host=os.getenv("HOST", "0.0.0.0"),
        port=int(os.getenv("PORT", "8787")),
        allowed_hosts=_csv("ALLOWED_HOSTS"),
        allowed_origins=_csv("ALLOWED_ORIGINS"),
        disable_dns_rebinding=_bool("DISABLE_DNS_REBINDING_PROTECTION", False),
    )
