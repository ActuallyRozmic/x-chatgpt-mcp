"""CLI entry: python -m x_chatgpt_mcp"""

from __future__ import annotations

import argparse
import sys


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(
        description="X Poster MCP server for ChatGPT (official X API v2)",
    )
    parser.add_argument(
        "--transport",
        choices=("streamable-http", "sse", "stdio"),
        default="streamable-http",
        help="MCP transport (default: streamable-http for ChatGPT)",
    )
    parser.add_argument("--host", default=None, help="Bind host (default: env HOST or 0.0.0.0)")
    parser.add_argument("--port", type=int, default=None, help="Bind port (default: env PORT or 8787)")
    parser.add_argument(
        "--check",
        action="store_true",
        help="Validate env/config and exit (does not start the server)",
    )
    args = parser.parse_args(argv)

    from .config import load_settings
    from . import server as server_mod

    settings = load_settings()
    host = args.host or settings.host
    port = args.port or settings.port

    if args.check:
        mode = settings.auth_mode
        print(f"auth_mode={mode or 'NOT CONFIGURED'}")
        print(f"api_base_url={settings.api_base_url}")
        print(f"listen={host}:{port}")
        try:
            settings.require_auth_ready()
            print("credentials: OK (present)")
            sys.exit(0)
        except RuntimeError as exc:
            print(f"credentials: MISSING — {exc}")
            sys.exit(2)

    if args.transport == "stdio":
        server_mod.mcp.run(transport="stdio")
        return

    if args.transport == "sse":
        print(
            f"Starting X ChatGPT MCP SSE on http://{host}:{port} "
            f"(auth={settings.auth_mode or 'not-set'})",
            flush=True,
        )
        server_mod.mcp.run(
            transport="sse",
            host=host,
            port=port,
            transport_security=server_mod.build_transport_security(settings),
        )
        return

    # Streamable HTTP via uvicorn + the module-level ASGI app (/mcp)
    if not settings.auth_mode:
        print(
            "WARNING: X credentials not set — tools will fail until .env is filled.",
            flush=True,
        )
    print(
        f"Starting X ChatGPT MCP on http://{host}:{port}/mcp "
        f"(transport=streamable-http, auth={settings.auth_mode or 'not-set'})",
        flush=True,
    )
    import uvicorn

    uvicorn.run(
        "x_chatgpt_mcp.server:app",
        host=host,
        port=port,
        log_level="info",
    )


if __name__ == "__main__":
    main()
