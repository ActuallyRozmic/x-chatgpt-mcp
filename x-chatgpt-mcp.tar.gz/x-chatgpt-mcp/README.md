# x-chatgpt-mcp

Custom **MCP server** that lets **ChatGPT** post to **X (Twitter)** using **your own** official X API v2 credentials — no Metricool, no scraping, no unofficial clients.

Transport: **Streamable HTTP** at `/mcp` (SSE also available). ChatGPT connects to a **public HTTPS** URL of this server.

---

## What it exposes

| Tool | When to use | X API call |
| --- | --- | --- |
| `get_me` | Verify which account will publish | `GET /2/users/me` |
| `create_post` | Publish one post (optional reply) | `POST /2/tweets` |
| `create_thread` | Publish an ordered thread | `POST /2/tweets` (once per item; each replies to the previous) |

All write tools accept `dry_run=true` to preview without calling X. Ask ChatGPT to confirm copy before real posts.

**Evidence (official endpoints):**

- Create post: [`POST https://api.x.com/2/tweets`](https://docs.x.com/x-api/posts/manage-tweets/quickstart)
- Authenticated user: [`GET https://api.x.com/2/users/me`](https://docs.x.com/x-api/users/lookup/get-me)

---

## Requirements

- Python **3.11+**
- An **X Developer Portal** app with **Read and Write** user permissions
- Prepaid **X API credits** (pay-per-use; posting is not free — check [console.x.com](https://console.x.com) for current rates)
- **ChatGPT Business, Enterprise, or Edu** workspace that allows **Add custom MCP server** (write plugins). Personal Plus/Pro often cannot add write MCP apps — confirm in your Plugins UI.
- A **public HTTPS** URL pointing at this server (ngrok, Cloudflare Tunnel, or a hosted deploy). ChatGPT cannot reach `localhost` unless you use OpenAI’s **Secure MCP Tunnel**.

---

## 1. Create an X Developer app

1. Open [https://console.x.com](https://console.x.com) and create / open a Project + App.
2. Set **App permissions** to **Read and write** (user auth).
3. Choose **one** credential path:

### Option A — OAuth 2.0 user access token (recommended)

1. Enable **OAuth 2.0** on the app.
2. Generate a **user-context** access token with scopes:
   - `tweet.read`
   - `tweet.write`
   - `users.read`
   - (optional) `offline.access` for refresh
3. Put the user access token in `.env` as `X_ACCESS_TOKEN`.
4. **Do not** use an app-only Bearer token — it cannot post.

### Option B — OAuth 1.0a user context

1. In the app keys page, create **Consumer Key / Secret** and **Access Token / Secret** with write access.
2. Set all four in `.env`:
   - `X_API_KEY`
   - `X_API_SECRET`
   - `X_ACCESS_TOKEN`
   - `X_ACCESS_TOKEN_SECRET`

---

## 2. Install and configure

### Linux / macOS

```bash
cd x-chatgpt-mcp
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
# or: pip install -e .
cp .env.example .env
# edit .env with your tokens
python -m x_chatgpt_mcp --check
```

### Windows (PowerShell)

```powershell
cd x-chatgpt-mcp
py -3 -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
copy .env.example .env
# edit .env
python -m x_chatgpt_mcp --check
```

`--check` exits `0` when credentials look present, `2` when missing (fails cleanly without tokens).

---

## 3. Run the MCP server

```bash
# Streamable HTTP (ChatGPT) — endpoint http://HOST:PORT/mcp
python -m x_chatgpt_mcp

# Equivalent uvicorn entrypoint
uvicorn x_chatgpt_mcp.server:app --host 0.0.0.0 --port 8787

# Optional SSE transport
python -m x_chatgpt_mcp --transport sse

# Local stdio (Claude Desktop / Inspector stdio clients — not ChatGPT)
python -m x_chatgpt_mcp --transport stdio
```

Default listen: `0.0.0.0:8787`, path **`/mcp`**.

### Expose HTTPS for ChatGPT

ChatGPT’s servers must reach your MCP URL over HTTPS.

**ngrok example:**

```bash
ngrok http 8787
# → https://abc123.ngrok-free.app
```

Then set in `.env` (restart the server):

```env
ALLOWED_HOSTS=abc123.ngrok-free.app
```

**Cloudflare Tunnel example:**

```bash
cloudflared tunnel --url http://127.0.0.1:8787
# → https://random.trycloudflare.com
```

```env
ALLOWED_HOSTS=random.trycloudflare.com
```

If Host checks still block you during a private test, you can temporarily set `DISABLE_DNS_REBINDING_PROTECTION=true` (only on a trusted machine / tunnel).

**ChatGPT Server URL field value (pattern):**

```text
https://<your-public-host>/mcp
```

Examples:

- `https://abc123.ngrok-free.app/mcp`
- `https://mcp.example.com/mcp`

Do **not** use `http://localhost:8787/mcp` in ChatGPT Plugins (OpenAI cannot dial your loopback). Use a tunnel, a deployed host, or ChatGPT’s **Secure MCP Tunnel** / Tunnel option if available in your workspace.

---

## 4. Add to ChatGPT (Business / Enterprise / Edu)

Per OpenAI’s current Plugins flow ([Creating custom MCP apps](https://help.openai.com/en/articles/12584461-creating-custom-mcp-apps-in-chatgpt), [Add custom MCP server](https://developers.openai.com/api/docs/guides/custom-mcp-server)):

1. Open ChatGPT on the **web** → **Plugins**.
2. Click **+** → **Add custom MCP server**.
3. Name: e.g. `X Poster`.
4. **Connection → Server URL:** `https://<your-public-host>/mcp`
   - Or choose **Tunnel** / Secure MCP Tunnel if your workspace supports connecting a private server.
5. Authentication: **No authentication** (this build keeps X tokens only on your server in `.env`). Add OAuth later if you harden it.
6. Acknowledge the risk warning → **Create as a plugin**.
7. Install the plugin, then in a chat type `@` and select it.
8. Test: ask it to run `get_me`, then `create_post` with `dry_run=true`, then a real short post after you confirm.

Supported transports: **Streamable HTTP** and **SSE**. This project defaults to Streamable HTTP.

---

## 5. Safety

- Credentials live only in `.env` (gitignored). Never paste tokens into ChatGPT.
- Prefer `dry_run=true` before live posts; ChatGPT should confirm copy.
- Tool annotations mark writes as non-read-only / open-world so ChatGPT can prompt for confirmation.
- Rate limits / credits: X pay-per-use pricing applies to `POST /2/tweets` (see your Developer Console). Duplicate text can 403.

---

## Project layout

```text
x-chatgpt-mcp/
├── README.md
├── .env.example
├── .gitignore
├── requirements.txt
├── pyproject.toml
└── x_chatgpt_mcp/
    ├── __init__.py
    ├── __main__.py      # python -m x_chatgpt_mcp
    ├── config.py        # env loading
    ├── x_client.py      # official X API v2 client
    └── server.py        # MCP tools + ASGI app
```

---

## Blockers / limits (read this)

| Blocker | Detail |
| --- | --- |
| **Public HTTPS required** | ChatGPT cannot call your laptop’s `localhost` unless you use OpenAI Secure MCP Tunnel or a public tunnel/deploy. |
| **Plan / workspace** | Custom write MCP plugins need a workspace that exposes **Add custom MCP server** (typically Business / Enterprise / Edu). |
| **X API billing** | Official posting is pay-per-use with your developer app — not free, and not Metricool. |
| **Token type** | App-only Bearer tokens **cannot** post; need user-context OAuth 2.0 or OAuth 1.0a. |
| **Media** | This v1 posts text (and reply chains). Media upload can be added later via X media endpoints. |

---

## License

MIT — use with your own X developer credentials and comply with the [X Developer Agreement](https://developer.x.com/en/developer-terms).
